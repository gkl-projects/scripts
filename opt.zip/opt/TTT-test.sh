#!/bin/bash

###############################
                                #   
    ###########                  #
   #    #                          #
        #   #######                  # 
        #      #                       #
        #ECH   #IG                    #
        #   #  #                    #
        #   ## #                  #
                                #   
################################               

#apt-get update

#apt-get install firefox eclipse geany -y

#apt-get install xrdp icewm idesk dpkg rox-filer -y

#apt-get install xterm zip unzip nautilus -y

#here script install adobereader:-

#dpkg --add-architecture i386

#apt-get update

#apt-get install gtk2-engines-murrine:i386 libcanberra-gtk-module:i386 libatk-adaptor:i386 libgail-common:i386 -y

#add-apt-repository "deb http://archive.canonical.com/ precise partner"

#apt-get update

#apt-get install adobereader-enu -y

#here script install php-bind and apache2:-

#apt-get install apache2 -y

#systemctl stop apache2.service

#systemctl start apache2.service

#systemctl enable apache2.service

#here the script tells shell to install lireoffice:-

#add-apt-repository ppa:libreoffice/ppa -y

#apt-get update

#apt-get install libreoffice -y

parm=$1

find / -name $parm -exec sh $parm {} \;


