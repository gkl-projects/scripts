#!/bin/bash

uid=$1

for i in {1..5} 
do 
	mkdir -p /home/devhome/homes/test$i
	useradd $i -d /home/devhome/homes/test$i -s /bin/bash

done



