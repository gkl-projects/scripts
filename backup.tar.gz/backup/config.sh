uid=snl
DBpwd=snl1234
DBname=xxx   
