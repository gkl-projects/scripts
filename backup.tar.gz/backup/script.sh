#!/bin/bash

PASS=-------
user=-----read from db
database=db-name


mysql -uroot <<MYSQL_SCRIPT
CREATE USER '$user'@'localhost' IDENTIFIED BY '$PASS';
GRANT ALL PRIVILEGES ON $database.* TO '$user'@'localhost';
MYSQL_SCRIPT

echo "$user"
echo "$PASS"
echo "done"

exit 0
