#!/bin/bash

apt-get update

apt-get install firefox eclipse geany -y

apt-get install xrdp icewm idesk dpkg rox-filer -y

apt-get install xterm zip unzip nautilus -y

#here script install adobereader:-

dpkg --add-architecture i386

apt-get update

apt-get install gtk2-engines-murrine:i386 libcanberra-gtk-module:i386 libatk-adaptor:i386 libgail-common:i386 -y

add-apt-repository "deb http://archive.canonical.com/ precise partner"

apt-get update

apt-get install adobereader-enu -y

#here script install php-bind and apache2:-

apt-get install apache2 -y

systemctl stop apache2.service

systemctl start apache2.service

systemctl enable apache2.service

#here the script tells shell to install lireoffice:-

add-apt-repository ppa:libreoffice/ppa -y

apt-get update

apt-get install libreoffice -y

#script create linkfiles:-

wget -O rox.png http://worldartsme.com/images/blue-ball-clipart-1.jpg

wget -O camunda.png https://www.enterpriseirregulars.com/wp-content/uploads/2016/09/camunda-logo.png

mv {camunda.png,rox.png,} /usr/share/pixmaps/

cp /usr/share/icons/hicolor/16x16/apps/firefox.png /usr/share/pixmaps/

cp /usr/share/icons/hicolor/16x16/apps/libreoffice-calc.png /usr/share/pixmaps/calc.png 

cp /usr/share/icons/hicolor/16x16/apps/libreoffice-writer.png /usr/share/pixmaps/writer.png

cp /usr/share/icons/hicolor/16x16/apps/libreoffice-impress.png /usr/share/pixmaps/impress.png

#hear script perform directory struchure:-

mkdir -p /home/ubuntu/backup/{handson,slides,outline,backup}

touch /home/ubuntu/backup/instructions

mkdir -p /home/ubuntu/{.icewm,.idesktop}

cp /usr/share/idesk/dot.ideskrc /home/ubuntu/.ideskrc

touch /home/ubuntu/.icewm/.ideskrc

echo "idesk >> /tmp/idesklog &" > /home/ubuntu/.icewm/startup

chmod +x /home/ubuntu/.icewm/startup

echo "FocusMode=0" > /home/ubuntu/.icewm/focus_mode

chown -R ubuntu:ubuntu /home/ubuntu

#here script wll perform loop:-

echo "table Icon
  Caption: Home
  ToolTip.Caption: MY Home
  Icon: /home/ubuntu/.idesktop/home.png
  Command[0]: nautilus /home/ubuntu
  Command[1]: nautilus /home/ubuntu/backup
end " >> /home/ubuntu/.ideskrc

echo "table Icon
  Caption: Courseware
  ToolTip.caption: /home/ubuntu/Guide
  Icon: /usr/share/pixmaps/camunda.png
  Width: 100
  Height: 100
  X: 0
  Y: 0
  Command[0]: nautilus /home/ubuntu/backup
  Command[1]: nautilus /home/ubuntu/backup/handson
end " > /home/ubuntu/.idesktop/home.lnk

var=(firefox.lnk geany.lnk eclipse.lnk rox.lnk Adobe.lnk calc.lnk writer.lnk impress.lnk)
var1=(firefox geany eclipse rox acroread libreoffice' '--calc libreoffice' '--writer libreoffice' '--impress)
var2=(firefox.png geany.xpm eclipse.png rox.png AdobeReader9.png calc.png writer.png impress.png)
var3=(Firefox Geany Eclipse Rox-filer Adobereader Office-calc Office-writer Office-impress)

for i in 0 1 2 3 4 5 6 7
do 
cp /usr/share/idesk/default.lnk /home/ubuntu/.idesktop/${var[$i]}
find / -name "${var[$i]}" -exec sed -i "s/Idesk/${var3[$i]}/g;s/48/32/g;s/30/0/g;s/idesk/pixmaps/g;s/folder_home.xpm/${var2[$i]}/g;s/xmessage/${var1[$i]} #/g" '{}' \;

done

#here the script tells shell to install java8:-

apt-get update

apt install openjdk-8-jdk-headless -y

export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64

export PATH=$JAVA_HOME/bin:$PATH

#here the script perform camunda install

wget https://camunda.org/release/camunda-bpm/tomcat/7.8/camunda-bpm-tomcat-7.8.0.tar.gz
 
tar -xzf camunda-bpm-tomcat-7.8.0.tar.gz -C /home/ubuntu

#here scripts tells shell to perform sed operations :-

sed -i 's/pdf=evince/pdf=acroread/g;s/plain=gedit/plain=geany/g;s/java=gedit/java=geany/g' /etc/gnome/defaults.list

sed -i 's/document=evince/document=libreoffice-writer/g' /etc/gnome/defaults.list 

sed -i 's/csv=libreoffice-calc/csv=geany/g' /etc/gnome/defaults.list 

chown -R ubuntu:ubuntu /home/ubuntu

echo -e "ub4ntu4\nub4ntu4" | (passwd ubuntu)

exit 0
