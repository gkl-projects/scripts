#!/bin/bash

apt-get update

apt-get install firefox eclipse geany -y

apt-get install xrdp icewm idesk dpkg rox-filer -y

apt-get install xterm zip unzip nautilus -y

#here script install adobereader:-

dpkg --add-architecture i386

apt-get update

apt-get install gtk2-engines-murrine:i386 libcanberra-gtk-module:i386 libatk-adaptor:i386 libgail-common:i386 -y

add-apt-repository "deb http://archive.canonical.com/ precise partner"

apt-get update

apt-get install adobereader-enu -y

#here script install php-bind and apache2:-

apt-get install apache2 -y

systemctl stop apache2.service

systemctl start apache2.service

systemctl enable apache2.service

#here the script tells shell to install lireoffice:-

add-apt-repository ppa:libreoffice/ppa -y

apt-get update

apt-get install libreoffice -y

#script create linkfiles:-

wget -O rox.png http://worldartsme.com/images/blue-ball-clipart-1.jpg

wget -O flink.png https://www.whizlabs.com/blog/wp-content/uploads/sites/2/2018/01/apache.png

mv {flink.png,rox.png,} /usr/share/pixmaps/

cp /usr/share/icons/hicolor/16x16/apps/firefox.png /usr/share/pixmaps/

cp /usr/share/icons/hicolor/16x16/apps/libreoffice-calc.png /usr/share/pixmaps/calc.png 

cp /usr/share/icons/hicolor/16x16/apps/libreoffice-writer.png /usr/share/pixmaps/writer.png

cp /usr/share/icons/hicolor/16x16/apps/libreoffice-impress.png /usr/share/pixmaps/impress.png

find / -name "config-python.ini" -exec cp {} /opt/ \;

find / -name "shell.config" -exec cp {} /opt/ \;

#hear script perform directory struchure:-

mkdir -p /home/ubuntu/backup/{handson,slides,outline,backup}

touch /home/ubuntu/backup/instructions

mkdir -p /home/ubuntu/{.icewm,.idesktop}

cp /usr/share/idesk/dot.ideskrc /home/ubuntu/.ideskrc

touch /home/ubuntu/.icewm/.ideskrc

echo "idesk >> /tmp/idesklog &" > /home/ubuntu/.icewm/startup

chmod +x /home/ubuntu/.icewm/startup

echo "FocusMode=0" > /home/ubuntu/.icewm/focus_mode

chown -R ubuntu:ubuntu /home/ubuntu

#here script wll perform loop:-

echo "table Icon
  Caption: Home
  ToolTip.Caption: MY Home
  Icon: /home/ubuntu/.idesktop/home.png
  Command[0]: nautilus /home/ubuntu
  Command[1]: nautilus /home/ubuntu/backup
end " >> /home/ubuntu/.ideskrc

echo "table Icon
  Caption: Courseware
  ToolTip.caption: /home/ubuntu/Guide
  Icon: /usr/share/pixmaps/flink.png
  Width: 100
  Height: 100
  X: 0
  Y: 0
  Command[0]: nautilus /home/ubuntu/backup
  Command[1]: nautilus /home/ubuntu/backup/handson
end " > /home/ubuntu/.idesktop/home.lnk

var=(firefox.lnk geany.lnk eclipse.lnk rox.lnk Adobe.lnk calc.lnk writer.lnk impress.lnk)
var1=(firefox geany eclipse rox acroread libreoffice' '--calc libreoffice' '--writer libreoffice' '--impress)
var2=(firefox.png geany.xpm eclipse.png rox.png AdobeReader9.png calc.png writer.png impress.png)
var3=(Firefox Geany Eclipse Rox-filer Adobereader Office-calc Office-writer Office-impress)

for i in 0 1 2 3 4 5 6 7 
do 
cp /usr/share/idesk/default.lnk /home/ubuntu/.idesktop/${var[$i]}
find / -name "${var[$i]}" -exec sed -i "s/Idesk/${var3[$i]}/g;s/48/32/g;s/30/0/g;s/idesk/pixmaps/g;s/folder_home.xpm/${var2[$i]}/g;s/xmessage/${var1[$i]} #/g" '{}' \;

done

#here the script tells shell to install java8:-

apt-get update

apt install openjdk-8-jdk-headless -y

export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64

export PATH=$JAVA_HOME/bin:$PATH

#here script tells shell to install flink:-

wget http://archive.apache.org/dist/flink/flink-1.2.0/flink-1.2.0-bin-hadoop27-scala_2.11.tgz

tar -xzf flink-1.2.0-bin-hadoop27-scala_2.11.tgz 

mv flink-1.2.0 flink

mv flink /home/ubuntu/

#here scripts tells shell to perform sed operations :-

sed -i 's/pdf=evince/pdf=acroread/g;s/plain=gedit/plain=geany/g;s/java=gedit/java=geany/g' /etc/gnome/defaults.list

sed -i 's/document=evince/document=libreoffice-writer/g' /etc/gnome/defaults.list 

sed -i 's/csv=libreoffice-calc/csv=geany/g' /etc/gnome/defaults.list 

#here script perform download file from s3:-

add-apt-repository ppa:jonathonf/python-3.6 -y

apt-get install python3.6 python3-pip python3-dev -y

apt install python-pip -y

pip install boto3


python <<@@

import boto3
from botocore.client import Config
import ConfigParser
import glob
import os

config=ConfigParser.ConfigParser()
config.read('/opt/config-python.ini')

ACCESS_KEY_ID=config.get('SETTINGS','Id')
ACCESS_SECRET_KEY=config.get('SETTINGS','Key')
BUCKET_NAME=config.get('SETTINGS','BUCKET_NAME')
FILE_NAME1=config.get('SETTINGS','file1')
#FILE_NAME2 =config.get('SETTINGS','file2')
#FILE_NAME3 =config.get('SETTINGS','file3')

data = open(FILE_NAME1,'w')
#data = open(FILE_NAME2, 'w')
#data = open(FILE_NAME3, 'w')

# S3 Connect
s3 = boto3.resource(
    's3',
    aws_access_key_id=ACCESS_KEY_ID,
    aws_secret_access_key=ACCESS_SECRET_KEY,
    config=Config(signature_version='s3v4')
)

#print (data)

# Image download
s3.Bucket(BUCKET_NAME).download_file(FILE_NAME1, '/home/ubuntu/backup/handson/'+FILE_NAME1);
#s3.Bucket(BUCKET_NAME).download_file(FILE_NAME2, './downloads/'+FILE_NAME2);
#s3.Bucket(BUCKET_NAME).download_file(FILE_NAME3, './downloads/'+FILE_NAME3);

####################   Download script  #########################

@@

. /opt/shell.config

chown -R ubuntu:ubuntu /home/ubuntu

echo -e "$userpwd\n$userpwd" | (passwd ubuntu)
